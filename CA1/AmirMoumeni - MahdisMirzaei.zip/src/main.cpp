#include "global.hpp"
#include "io.hpp"

int main() {

    Interface interface;
    interface.run();

    return 0;
}
